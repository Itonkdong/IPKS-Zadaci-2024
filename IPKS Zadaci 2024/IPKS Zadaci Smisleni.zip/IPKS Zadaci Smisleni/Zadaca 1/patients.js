let patientsData = [
    {
        "id": 1,
        "name": "Name 1",
        "surname": "Surname 1",
        "disease": "Disease 1",
        "doctor": "Doctor 1"
    },
    {
        "id": 2,
        "name": "Name 2",
        "surname": "Surname 2",
        "disease": "Disease 2",
        "doctor": "Doctor 2"
    },
    {
        "id": 3,
        "name": "Name 3",
        "surname": "Surname 3",
        "disease": "Disease 3",
        "doctor": "Doctor 3"
    },
    {
        "id": 4,
        "name": "Name 4",
        "surname": "Surname 4",
        "disease": "Disease 4",
        "doctor": "Doctor 4"
    },
    {
        "id": 5,
        "name": "Name 5",
        "surname": "Surname 5",
        "disease": "Disease 5",
        "doctor": "Doctor 5"
    }
]